package udemy.appdev.arithmatrix.ui.basic

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backspace
import androidx.compose.material.icons.filled.Functions
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import udemy.appdev.arithmatrix.ui.BottomNavBar
import udemy.appdev.arithmatrix.ui.theme.ButtonDark
import udemy.appdev.arithmatrix.ui.theme.ButtonMid

private val SciColor = Color(0xFF4A4580)

// Represents a single button cell in the grid
data class ButtonCell(
    val label: String,           // display text
    val input: String = label,   // what gets sent to viewModel.onInput()
    val type: CellType = CellType.DIGIT
)

enum class CellType { DIGIT, OPERATOR, SPECIAL, SCI, EMPTY, EQUALS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BasicScreen(
    navController: NavHostController,
    viewModel: BasicViewModel = hiltViewModel(),
    modifier: Modifier = Modifier
) {
    val expression by viewModel.expression.collectAsState()
    val result by viewModel.result.collectAsState()
    val isScientific by viewModel.isScientific.collectAsState()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current

    // ── Build the flat button list for the grid ───────────────────────────────
    // Grid is always 5 columns when scientific, 4 columns when normal.
    // We rebuild the list whenever isScientific changes.

    val normalButtons = listOf(
        // row 1
        ButtonCell("(", type = CellType.SPECIAL),
        ButtonCell(")", type = CellType.SPECIAL),
        ButtonCell("%", type = CellType.SPECIAL),
        ButtonCell("÷", type = CellType.OPERATOR),
        // row 2
        ButtonCell("AC", type = CellType.SPECIAL),
        ButtonCell("⌫", type = CellType.SPECIAL),   // backspace — handled specially in UI
        ButtonCell("×", type = CellType.OPERATOR),
        // row 2 gap — AC has no 2nd neighbour so we fill with empty to keep 4-col grid
        // Actually: AC | ⌫ | × needs one more → put empty slot
        // Reorder to keep 4 per row: AC | empty | ⌫ | ×
        // Simplest: just list all 4
    )
    // Build rows explicitly so layout intent is crystal clear
    val buttons4col: List<ButtonCell> = listOf(
        // row 1 — brackets + operators
        ButtonCell("(", type = CellType.SPECIAL),
        ButtonCell(")", type = CellType.SPECIAL),
        ButtonCell("%", type = CellType.SPECIAL),
        ButtonCell("÷", type = CellType.OPERATOR),
        // row 2 — AC row
        ButtonCell("AC", type = CellType.SPECIAL),
        ButtonCell("÷", input = "÷", type = CellType.OPERATOR), // second ÷ only shown in sci; keep slot
        ButtonCell("⌫", type = CellType.SPECIAL),
        ButtonCell("×", type = CellType.OPERATOR),
        // row 3
        ButtonCell("7"), ButtonCell("8"), ButtonCell("9"),
        ButtonCell("-", type = CellType.OPERATOR),
        // row 4
        ButtonCell("4"), ButtonCell("5"), ButtonCell("6"),
        ButtonCell("+", type = CellType.OPERATOR),
        // row 5
        ButtonCell("1"), ButtonCell("2"), ButtonCell("3"),
        ButtonCell("", type = CellType.EMPTY),
        // row 6
        ButtonCell("00"), ButtonCell("0"), ButtonCell("."),
        ButtonCell("=", type = CellType.EQUALS),
    )

    // 5-col scientific layout — every row is 5 buttons wide
    val buttons5col: List<ButtonCell> = listOf(
        // sci row 1
        ButtonCell("sin", type = CellType.SCI),
        ButtonCell("cos", type = CellType.SCI),
        ButtonCell("tan", type = CellType.SCI),
        ButtonCell("√",   type = CellType.SCI),
        ButtonCell("x²",  type = CellType.SCI),
        // sci row 2
        ButtonCell("log", type = CellType.SCI),
        ButtonCell("ln",  type = CellType.SCI),
        ButtonCell("(",   type = CellType.SPECIAL),
        ButtonCell(")",   type = CellType.SPECIAL),
        ButtonCell("%",   type = CellType.SPECIAL),
        // row 3 — AC row
        ButtonCell("AC",  type = CellType.SPECIAL),
        ButtonCell("÷",   type = CellType.OPERATOR),
        ButtonCell("⌫",   type = CellType.SPECIAL),
        ButtonCell("×",   type = CellType.OPERATOR),
        ButtonCell("",    type = CellType.EMPTY),   // filler to keep 5-col alignment
        // row 4
        ButtonCell("7"), ButtonCell("8"), ButtonCell("9"),
        ButtonCell("-", type = CellType.OPERATOR),
        ButtonCell("", type = CellType.EMPTY),
        // row 5
        ButtonCell("4"), ButtonCell("5"), ButtonCell("6"),
        ButtonCell("+", type = CellType.OPERATOR),
        ButtonCell("", type = CellType.EMPTY),
        // row 6
        ButtonCell("1"), ButtonCell("2"), ButtonCell("3"),
        ButtonCell("", type = CellType.EMPTY),
        ButtonCell("", type = CellType.EMPTY),
        // row 7
        ButtonCell("00"), ButtonCell("0"), ButtonCell("."),
        ButtonCell("=", type = CellType.EQUALS),
        ButtonCell("", type = CellType.EMPTY),
    )

    val columns   = if (isScientific) 5 else 4
    val buttons   = if (isScientific) buttons5col else buttons4col

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        "ArithMatrix",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleScientific() }) {
                        Icon(
                            Icons.Default.Functions,
                            contentDescription = "Toggle scientific mode",
                            tint = if (isScientific) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { navController.navigate("history") }) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            )
        },
        bottomBar = { BottomNavBar(navController = navController) }
    ) { innerPadding ->
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
        ) {
            val screenW    = maxWidth
            val screenH    = maxHeight
            val gridPadH   = 12.dp
            val buttonGap  = 10.dp
            val gaps       = buttonGap * (columns - 1)
            val buttonSize = (screenW - gridPadH * 2 - gaps) / columns

            Column(modifier = Modifier.fillMaxSize()) {

                // ── Display ──────────────────────────────────────────
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.Bottom,
                    horizontalAlignment = Alignment.End
                ) {
                    val exprScroll = rememberScrollState()
                    Text(
                        text = expression,
                        fontSize = 26.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                        textAlign = TextAlign.End,
                        maxLines = 1,
                        modifier = Modifier.horizontalScroll(exprScroll)
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = result,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.End,
                            maxLines = 1,
                            modifier = Modifier.weight(1f)
                        )
                        if (result.isNotEmpty() && result != "Error") {
                            IconButton(onClick = {
                                val intent = android.content.Intent().apply {
                                    action = android.content.Intent.ACTION_SEND
                                    putExtra(
                                        android.content.Intent.EXTRA_TEXT,
                                        "$expression = $result"
                                    )
                                    type = "text/plain"
                                }
                                context.startActivity(
                                    android.content.Intent.createChooser(intent, "Share result")
                                )
                            }) {
                                Icon(
                                    Icons.Default.Share,
                                    contentDescription = "Share result",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }

                // ── Fixed-size grid ───────────────────────────────────
                // LazyVerticalGrid with fixed buttonSize — every button identical
                LazyVerticalGrid(
                    columns        = GridCells.Fixed(columns),
                    modifier       = Modifier
                        .fillMaxWidth()
                        .wrapContentHeight()
                        .padding(horizontal = gridPadH, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(buttonGap),
                    verticalArrangement   = Arrangement.spacedBy(buttonGap),
                    userScrollEnabled     = false   // keyboard never scrolls
                ) {
                    items(buttons) { cell ->
                        GridButton(
                            cell       = cell,
                            size       = buttonSize,
                            haptic     = haptic,
                            isBackspace = cell.label == "⌫",
                            onClick    = {
                                if (cell.type != CellType.EMPTY) {
                                    viewModel.onInput(cell.input)
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

// ── Single grid button ────────────────────────────────────────────────────────

@Composable
fun GridButton(
    cell: ButtonCell,
    size: androidx.compose.ui.unit.Dp,
    haptic: HapticFeedback?,
    isBackspace: Boolean = false,
    onClick: () -> Unit
) {
    val background = when (cell.type) {
        CellType.OPERATOR -> MaterialTheme.colorScheme.secondary
        CellType.SPECIAL  -> ButtonMid
        CellType.SCI      -> SciColor
        CellType.EQUALS   -> MaterialTheme.colorScheme.primary
        CellType.DIGIT    -> ButtonDark
        CellType.EMPTY    -> Color.Transparent
    }

    val description = when (cell.label) {
        "⌫"  -> "backspace"
        "√"  -> "square root"
        "x²" -> "x squared"
        "÷"  -> "divide"
        "×"  -> "multiply"
        "+"  -> "plus"
        "-"  -> "minus"
        "="  -> "equals"
        "%"  -> "percent"
        ""   -> "empty"
        else -> cell.label
    }

    if (cell.type == CellType.EMPTY) {
        // Invisible placeholder — same size, not tappable
        Box(modifier = Modifier.size(size))
        return
    }

    Button(
        onClick = {
            haptic?.performHapticFeedback(HapticFeedbackType.LongPress)
            onClick()
        },
        shape  = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = background),
        modifier = Modifier
            .size(size)
            .semantics { contentDescription = description },
        contentPadding = PaddingValues(0.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
    ) {
        if (isBackspace) {
            Icon(
                Icons.Default.Backspace,
                contentDescription = "backspace",
                tint = Color.White,
                modifier = Modifier.size(size * 0.38f)
            )
        } else {
            Text(
                text       = cell.label,
                fontSize   = when {
                    cell.label.length >= 3 -> (size.value * 0.24f).sp   // sin/cos/tan/log/etc
                    cell.label.length == 2 -> (size.value * 0.28f).sp   // x² / 00 / AC
                    else                   -> (size.value * 0.36f).sp   // single char
                },
                fontWeight = FontWeight.Bold,
                color      = Color.White,
                maxLines   = 1,
                softWrap   = false,
                textAlign  = TextAlign.Center
            )
        }
    }
}