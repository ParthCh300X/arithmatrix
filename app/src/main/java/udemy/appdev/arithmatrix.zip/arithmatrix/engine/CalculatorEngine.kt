package udemy.appdev.arithmatrix.engine

import java.util.Stack

class CalculatorEngine {

    fun evaluate(expression: String): Double {
        val sanitized = expression
            .replace("×", "*")
            .replace("÷", "/")
            .replace("x", "*")
        return evaluateExpression(sanitized)
    }

    fun formatResult(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "Error"
        return if (value == kotlin.math.floor(value) && !value.isInfinite()) {
            value.toLong().toString()
        } else {
            "%.10g".format(value).trimEnd('0').trimEnd('.')
        }
    }

    private fun evaluateExpression(expression: String): Double {
        val values = Stack<Double>()
        val ops = Stack<Char>()
        var i = 0

        while (i < expression.length) {
            val c = expression[i]
            when {
                c == ' ' -> { /* skip */ }

                c.isDigit() || c == '.' -> {
                    val sb = StringBuilder()
                    while (i < expression.length && (expression[i].isDigit() || expression[i] == '.')) {
                        sb.append(expression[i++])
                    }
                    values.push(sb.toString().toDouble())
                    i--
                }

                c == '(' -> ops.push(c)

                c == ')' -> {
                    while (ops.isNotEmpty() && ops.peek() != '(') {
                        if (values.size < 2) throw ArithmeticException("Invalid expression")
                        values.push(applyOps(ops.pop(), values.pop(), values.pop()))
                    }
                    if (ops.isEmpty()) throw ArithmeticException("Mismatched parentheses")
                    ops.pop() // remove '('
                }

                c == '%' -> {
                    if (values.isNotEmpty()) {
                        val num = values.pop()
                        val base = if (ops.isNotEmpty() && (ops.peek() == '+' || ops.peek() == '-')) {
                            if (values.isNotEmpty()) values.peek() else num
                        } else 1.0
                        values.push(num * base / 100.0)
                    }
                }

                c == '+' || c == '-' || c == '*' || c == '/' -> {
                    while (ops.isNotEmpty() && ops.peek() != '(' && hasPrecedence(c, ops.peek())) {
                        if (values.size < 2) throw ArithmeticException("Invalid expression")
                        values.push(applyOps(ops.pop(), values.pop(), values.pop()))
                    }
                    ops.push(c)
                }
            }
            i++
        }

        while (ops.isNotEmpty()) {
            if (ops.peek() == '(') throw ArithmeticException("Mismatched parentheses")
            if (values.size < 2) throw ArithmeticException("Invalid expression")
            values.push(applyOps(ops.pop(), values.pop(), values.pop()))
        }

        if (values.isEmpty()) throw ArithmeticException("Invalid expression")
        return values.pop()
    }

    private fun hasPrecedence(op1: Char, op2: Char): Boolean {
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) return false
        return true
    }

    private fun applyOps(op: Char, b: Double, a: Double): Double {
        return when (op) {
            '+' -> a + b
            '-' -> a - b
            '*' -> a * b
            '/' -> {
                if (b == 0.0) throw ArithmeticException("Division by zero")
                a / b
            }
            else -> throw ArithmeticException("Unknown operator: $op")
        }
    }
}